#!/bin/bash
salt-call --local grains.item id
PUB_IP=`curl http://169.254.169.254/latest/meta-data/public-ipv4 --silent`
PRIV_IP=`curl http://169.254.169.254/latest/meta-data/local-ipv4  --silent`
echo "public ip: $PUB_IP"
echo "private ip: $PRIV_IP"
